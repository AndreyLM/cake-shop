<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 15.06.17
 * Time: 8:39
 */

namespace domain;


class NotFoundException extends \DomainException
{

}